import java.util.Date;

public class FlightNode {
    
    //attributes
    private String registration_no;
    Date arrival_date;
    
    //default constructor 
    public FlightNode() {
    }
    
    // loaded constructor 
    public FlightNode(String registration_no, Date arrival_date) {
        this.registration_no = registration_no;
        this.arrival_date = arrival_date;
    }
    
    //getter methods 
    public String getRegistrationNo() {
        return registration_no;
    }
    
    public Date getArrivalDate() {
        return arrival_date;
    }
    
    //setter methods 
    public void setRegistrationNo(String registration_no) {
        this.registration_no = registration_no;
    }
    
    public void setArrivalDate(Date arrival_date) {
        this.arrival_date = arrival_date;
    }
    
    //toString() method 
    @Override
    public String toString() {
        return "Flight registration no.: " + registration_no +
               "\nArrival date: " + arrival_date.toString();
    }
    
}
