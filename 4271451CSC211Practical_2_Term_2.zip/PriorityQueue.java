public class PriorityQueue {
    
    // attributes
    private int currentSize;                 //stores current number of elements in PQ
    private FlightNode[] array;              //array to store flight nodes, implements PQ
    private final int DEFAULT_CAPACITY = 2 << 10;  //maximum heap size
    
    // default constructor 
    public PriorityQueue() {
        currentSize = 0;
        array = new FlightNode[DEFAULT_CAPACITY];
    }
    
    // loaded constructor 
    public PriorityQueue(int capacity) {
        currentSize = 0;
        array = new FlightNode[capacity];
    }
    
    // getter methods 
    public int getCurrentSize() {
        return currentSize;
    }
    
    public FlightNode[] getArray() {
        return array;
    }
    
    /* setter methods */
    public void setCurrentSize(int currentSize) {
        this.currentSize = currentSize;
    }
    
    public void setArray(FlightNode[] array) {
        this.array = array;
    }
    
    //clear the heap
    public void clear() {
        currentSize = 0;
        array = new FlightNode[DEFAULT_CAPACITY];
    }
    
    //check if heap is empty
    public boolean isEmpty() {
        return currentSize == 0;
    }
    
    //adding a new element to the heap 
    public boolean add(FlightNode x) {
        if (currentSize == array.length - 1) {
            FlightNode[] flightNode = new FlightNode[array.length * 2];  // if heap is full, double its size
            array = flightNode;   
        }

        //insert new element at bottom of heap
        int hole = ++currentSize;
        array[hole] = x;

        // percolate up to restore heap property
        for (; hole > 1 && x.arrival_date.before(array[hole / 2].arrival_date); hole /= 2) {
            array[hole] = array[hole / 2];
        }
        array[hole] = x;
        return true;
    }
    
    //method to remove the element at the top of the heap 
    public FlightNode remove() {
        if (isEmpty()) {
            return null;
        }
        //remove the root and replace with the last element in the heap
        FlightNode minElement = array[1];
        array[1] = array[currentSize--];

        //percolate down and restore heap property
        percolateDown(1);
        return minElement;
    }
    
    //percolate down and restore heap property 
    private void percolateDown(int hole) {
        FlightNode temp = array[hole];
        array[hole] = temp;
    }
}
