import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main{

	public static void main(String[] args) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader("planes.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                System.out.println(values[0] + values[1] + values[2]);  //printing the values
                
            }
        } catch (FileNotFoundException e) {        //Catch statements if anything goes wrong searching for file
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    //date formating method
    public static Date formatDate(int day, int month, int year, int hours, int minutes, int seconds) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String dateString = day + "/" + month + "/" + year + " " + hours + ":" + minutes + ":" + seconds;
        Date date = null;
        try {
            date = dateFormat.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        } 
        return date;
    }   
}